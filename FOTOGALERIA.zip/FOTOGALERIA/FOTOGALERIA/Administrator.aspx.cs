﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FOTOGALERIA
{
    public partial class Administrator : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void ButtonDodajAktualnosci_Click(object sender, EventArgs e)
        {
            using (EntitiesFotogaleria context = new EntitiesFotogaleria())

                try
                {
                    Aktualnosci aktual = new Aktualnosci();
                    aktual.TrescAktualnosci = this.TextBoxTrescAktualnosci.Text;
                    aktual.DataAktualnosci = DateTime.Now;

                    context.Aktualnosci.Add(aktual);
                    context.SaveChanges();

                    this.LabelDodanieAktualnosci.Text = "Treść aktualności została zapisana!";
                    this.TextBoxTrescAktualnosci.Text = String.Empty;
                }

                catch
                {
                    this.LabelDodanieAktualnosci.Text = "Błąd!";
                }
        }


        protected void ButtonZarzadzanieUzytkownikami_Click(object sender, EventArgs e)
        {
            this.GridViewZarzadzanieUzytkownikami.DataSourceID = "EntityDataSourceUzytkownicy";
            this.GridViewZarzadzanieUzytkownikami.Visible = true;
            this.GridViewZarzadzanieAktualnosciami.Visible = false;
            this.GridViewZarzadzanieZdjeciami.Visible = false;            
        }


        protected void ButtonZarzadzanieZdjeciami_Click(object sender, EventArgs e)
        {
            this.GridViewZarzadzanieZdjeciami.DataSourceID = "EntityDataSourceZdjecia";
            this.GridViewZarzadzanieZdjeciami.Visible = true;
            this.GridViewZarzadzanieAktualnosciami.Visible = false;
            this.GridViewZarzadzanieUzytkownikami.Visible = false;
        }


        protected void ButtonZarzadzanieAktualnosciami_Click(object sender, EventArgs e)
        {
            this.GridViewZarzadzanieAktualnosciami.DataSourceID = "EntityDataSourceAktualnosci";
            this.GridViewZarzadzanieAktualnosciami.Visible = true;
            this.GridViewZarzadzanieUzytkownikami.Visible = false;
            this.GridViewZarzadzanieZdjeciami.Visible = false;    
        }


    }
}