﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace FOTOGALERIA
{
    public partial class DodawanieZdjec : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }



        //WYSWIETL ZDJECIA
        //protected void ButtonWyswietlZdjecia_Click(object sender, EventArgs e)
        //{
        //    using (EntitiesFotogaleria context = new EntitiesFotogaleria())
        //    {
        //        var zdjecia = context.KategoriaCzlowiek();
        //        Repeater1.DataSource = zdjecia.Select(i => new { Sciezka = i });
        //        DataBind();
        //    }
        //}



        //DODAWANIE ZDJEC
        protected void ButtonDodajZdjecie_Click(object sender, EventArgs e)
        {
            String filePath = Server.MapPath(@"~/Images/" + FileUploadWybierzZdjecie.FileName);
            using (EntitiesFotogaleria context = new EntitiesFotogaleria())


                if (FileUploadWybierzZdjecie.HasFile && Path.GetExtension(FileUploadWybierzZdjecie.FileName) == ".jpg")
                {


                    //jeżeli nie wybrano kategorii zdjęcia
                    if (WyborKategoriiZdjecia.SelectedIndex == 0)
                    {
                        this.LabelKomunikat.Text = "Wybierz kategorię zdjęcia";
                    }



                    //kategoria Człowiek, ID kategorii = 4
                    if (WyborKategoriiZdjecia.SelectedIndex == 1)
                    {

                        if (FileUploadWybierzZdjecie.PostedFile.ContentLength < 2097152)   //ograniczenie wielkości pliku do 2MB
                        {

                            try
                            {
                                MembershipUser currentUser = Membership.GetUser();
                                string currentUserID = currentUser.ProviderUserKey.ToString();

                                Zdjecia noweZdjecie = new Zdjecia();
                                //noweZdjecie.UserId = HttpContext.Current.User.Identity.Name
                                //noweZdjecie.UserId = Membership.GetUser(HttpContext.Current.User.Identity.Name).ProviderUserKey;
                                noweZdjecie.UserId = new Guid(currentUserID);
                                noweZdjecie.idKategorii = 4;
                                noweZdjecie.dataDodania = DateTime.Now;
                                noweZdjecie.opisZdjecia = TextBoxOpisZdjecia.Text;
                                noweZdjecie.kategoriaZdjecia = "człowiek";
                                noweZdjecie.zdjecie = "../Images/" + FileUploadWybierzZdjecie.FileName;
                                context.Zdjecia.Add(noweZdjecie);
                                context.SaveChanges();
                                FileUploadWybierzZdjecie.SaveAs(filePath);
                                this.LabelKomunikat.Text = "Zdjęcie zostało dodane";
                            }

                            catch
                            {
                                this.LabelKomunikat.Text = "Nieudane dodanie zdjęcia";
                            }
                        }

                        else
                        {
                            this.LabelKomunikat.Text = "Plik jest zbyt duży (dopuszczalne 2MB)!";
                            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Plik jest zbyt duży (dopuszczalne 2MB)!')", true);
                        }
                    }



                    //kategoria Pejzaż, ID kategorii = 6
                    if (WyborKategoriiZdjecia.SelectedIndex == 2)
                    {

                        if (FileUploadWybierzZdjecie.PostedFile.ContentLength < 2097152)   //ograniczenie wielkości pliku do 2MB
                        {

                            try
                            {
                                MembershipUser currentUser = Membership.GetUser();
                                string currentUserID = currentUser.ProviderUserKey.ToString();

                                Zdjecia noweZdjecie = new Zdjecia();
                                //noweZdjecie.UserId = HttpContext.Current.User.Identity.Name
                                //noweZdjecie.UserId = Membership.GetUser(HttpContext.Current.User.Identity.Name).ProviderUserKey;
                                noweZdjecie.UserId = new Guid(currentUserID);
                                noweZdjecie.idKategorii = 6;
                                noweZdjecie.dataDodania = DateTime.Now;
                                noweZdjecie.opisZdjecia = TextBoxOpisZdjecia.Text;
                                noweZdjecie.kategoriaZdjecia = "pejzaż";
                                noweZdjecie.zdjecie = "../Images/" + FileUploadWybierzZdjecie.FileName;
                                context.Zdjecia.Add(noweZdjecie);
                                context.SaveChanges();
                                FileUploadWybierzZdjecie.SaveAs(filePath);
                                this.LabelKomunikat.Text = "Zdjęcie zostało dodane";
                            }

                            catch
                            {
                                this.LabelKomunikat.Text = "Nieudane dodanie zdjęcia";
                            }
                        }

                        else
                        {
                            this.LabelKomunikat.Text = "Plik jest zbyt duży (dopuszczalne 2MB)!";
                            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Plik jest zbyt duży (dopuszczalne 2MB)!')", true);
                        }
                    }



                    //kategoria Zwierzęta, ID kategorii = 3
                    if (WyborKategoriiZdjecia.SelectedIndex == 3)
                    {

                        if (FileUploadWybierzZdjecie.PostedFile.ContentLength < 2097152)   //ograniczenie wielkości pliku do 2MB
                        {

                            try
                            {
                                MembershipUser currentUser = Membership.GetUser();
                                string currentUserID = currentUser.ProviderUserKey.ToString();

                                Zdjecia noweZdjecie = new Zdjecia();
                                //noweZdjecie.UserId = HttpContext.Current.User.Identity.Name
                                //noweZdjecie.UserId = Membership.GetUser(HttpContext.Current.User.Identity.Name).ProviderUserKey;
                                noweZdjecie.UserId = new Guid(currentUserID);
                                noweZdjecie.idKategorii = 3;
                                noweZdjecie.dataDodania = DateTime.Now;
                                noweZdjecie.opisZdjecia = TextBoxOpisZdjecia.Text;
                                noweZdjecie.kategoriaZdjecia = "zwierzęta";
                                noweZdjecie.zdjecie = "../Images/" + FileUploadWybierzZdjecie.FileName;
                                context.Zdjecia.Add(noweZdjecie);
                                context.SaveChanges();
                                FileUploadWybierzZdjecie.SaveAs(filePath);
                                this.LabelKomunikat.Text = "Zdjęcie zostało dodane";
                            }

                            catch
                            {
                                this.LabelKomunikat.Text = "Nieudane dodanie zdjęcia";
                            }
                        }

                        else
                        {
                            this.LabelKomunikat.Text = "Plik jest zbyt duży (dopuszczalne 2MB)!";
                            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Plik jest zbyt duży (dopuszczalne 2MB)!')", true);
                        }
                    }



                    //kategoria Motoryzacja, ID kategorii = 5
                    if (WyborKategoriiZdjecia.SelectedIndex == 4)
                    {

                        if (FileUploadWybierzZdjecie.PostedFile.ContentLength < 2097152)   //ograniczenie wielkości pliku do 2MB
                        {

                            try
                            {
                                MembershipUser currentUser = Membership.GetUser();
                                string currentUserID = currentUser.ProviderUserKey.ToString();

                                Zdjecia noweZdjecie = new Zdjecia();
                                //noweZdjecie.UserId = HttpContext.Current.User.Identity.Name
                                //noweZdjecie.UserId = Membership.GetUser(HttpContext.Current.User.Identity.Name).ProviderUserKey;
                                noweZdjecie.UserId = new Guid(currentUserID);
                                noweZdjecie.idKategorii = 5;
                                noweZdjecie.dataDodania = DateTime.Now;
                                noweZdjecie.opisZdjecia = TextBoxOpisZdjecia.Text;
                                noweZdjecie.kategoriaZdjecia = "motoryzacja";
                                noweZdjecie.zdjecie = "../Images/" + FileUploadWybierzZdjecie.FileName;
                                context.Zdjecia.Add(noweZdjecie);
                                context.SaveChanges();
                                FileUploadWybierzZdjecie.SaveAs(filePath);
                                this.LabelKomunikat.Text = "Zdjęcie zostało dodane";
                            }

                            catch
                            {
                                this.LabelKomunikat.Text = "Nieudane dodanie zdjęcia";
                            }
                        }

                        else
                        {
                            this.LabelKomunikat.Text = "Plik jest zbyt duży (dopuszczalne 2MB)!";
                            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Plik jest zbyt duży (dopuszczalne 2MB)!')", true);
                        }
                    }



                    //kategoria Sport, ID kategorii = 2
                    if (WyborKategoriiZdjecia.SelectedIndex == 5)
                    {

                        if (FileUploadWybierzZdjecie.PostedFile.ContentLength < 2097152)   //ograniczenie wielkości pliku do 2MB
                        {

                            try
                            {
                                MembershipUser currentUser = Membership.GetUser();
                                string currentUserID = currentUser.ProviderUserKey.ToString();

                                Zdjecia noweZdjecie = new Zdjecia();
                                //noweZdjecie.UserId = HttpContext.Current.User.Identity.Name
                                //noweZdjecie.UserId = Membership.GetUser(HttpContext.Current.User.Identity.Name).ProviderUserKey;
                                noweZdjecie.UserId = new Guid(currentUserID);
                                noweZdjecie.idKategorii = 2;
                                noweZdjecie.dataDodania = DateTime.Now;
                                noweZdjecie.opisZdjecia = TextBoxOpisZdjecia.Text;
                                noweZdjecie.kategoriaZdjecia = "sport";
                                noweZdjecie.zdjecie = "../Images/" + FileUploadWybierzZdjecie.FileName;
                                context.Zdjecia.Add(noweZdjecie);
                                context.SaveChanges();
                                FileUploadWybierzZdjecie.SaveAs(filePath);
                                this.LabelKomunikat.Text = "Zdjęcie zostało dodane";
                            }

                            catch
                            {
                                this.LabelKomunikat.Text = "Nieudane dodanie zdjęcia";
                            }
                        }

                        else
                        {
                            this.LabelKomunikat.Text = "Plik jest zbyt duży (dopuszczalne 2MB)!";
                            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Plik jest zbyt duży (dopuszczalne 2MB)!')", true);
                        }
                    }



                    //kategoria Inne, ID kategorii = 7
                    if (WyborKategoriiZdjecia.SelectedIndex == 6)
                    {

                        if (FileUploadWybierzZdjecie.PostedFile.ContentLength < 2097152)   //ograniczenie wielkości pliku do 2MB
                        {

                            try
                            {
                                MembershipUser currentUser = Membership.GetUser();
                                string currentUserID = currentUser.ProviderUserKey.ToString();

                                Zdjecia noweZdjecie = new Zdjecia();
                                //noweZdjecie.UserId = HttpContext.Current.User.Identity.Name
                                //noweZdjecie.UserId = Membership.GetUser(HttpContext.Current.User.Identity.Name).ProviderUserKey;
                                noweZdjecie.UserId = new Guid(currentUserID);
                                noweZdjecie.idKategorii = 7;
                                noweZdjecie.dataDodania = DateTime.Now;
                                noweZdjecie.opisZdjecia = TextBoxOpisZdjecia.Text;
                                noweZdjecie.kategoriaZdjecia = "inne";
                                noweZdjecie.zdjecie = "../Images/" + FileUploadWybierzZdjecie.FileName;
                                context.Zdjecia.Add(noweZdjecie);
                                context.SaveChanges();
                                FileUploadWybierzZdjecie.SaveAs(filePath);
                                this.LabelKomunikat.Text = "Zdjęcie zostało dodane";
                            }

                            catch
                            {
                                this.LabelKomunikat.Text = "Nieudane dodanie zdjęcia";
                            }
                        }

                        else
                        {
                            this.LabelKomunikat.Text = "Plik jest zbyt duży (dopuszczalne 2MB)!";
                            //Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Plik jest zbyt duży (dopuszczalne 2MB)!')", true);
                        }
                    }
                    




                }


                else
                {
                    LabelKomunikat.Text = "Błąd! Sprawdź, plik (tylko .jpg)!";
                }
        }


    }
}